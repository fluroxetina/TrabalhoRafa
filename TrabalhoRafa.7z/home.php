<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="homeStyle.css">
</head>

<body>

    <h1>Reservas</h1>
    <div class="tabela">
        <nav>
            <a href="CadastrarEspaco.php">Cadastrar Espaco</a>
            <a href="CadastrarUsuario.php">Cadastrar Usuario</a>
            <a href="ReservarEspaco.php">Reservar Espaco</a>
        </nav>
    </div>

    
</body>

</html>